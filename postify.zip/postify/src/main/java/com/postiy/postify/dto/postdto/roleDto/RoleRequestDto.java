package com.postiy.postify.dto.postdto.roleDto;

import lombok.Data;

import java.util.Set;

@Data
public class RoleRequestDto {
   private int userId;
    private int roleId;
}
